///<reference types ="cypress" />

import HomePageActions from '../../pageobjects/pageactions/HomePageActions'
import PropertyIdentificationActionsPage from '../../pageobjects/pageactions/PropertyIdentificationActionsPage'

describe("Perform Object to Rating Valuation",()=>{

    const homePageActions = new HomePageActions();
    const propertyIdentificationActionsPage = new PropertyIdentificationActionsPage();

    before(()=>{

    cy.fixture('testdata').then((data)=>{

    globalThis.data = data
})


})

it("Begin the Process",()=>{

    homePageActions.navigateToUrl()
    homePageActions.startProcess()



})

it("Enter Personal Details",()=>{


    propertyIdentificationActionsPage.enterPersonalDetails(data.firstName,data.lastName,data.type,data.postalAddress,data.Suburb,data.State,data.PostCode,data.Email,data.Phone)



})




})