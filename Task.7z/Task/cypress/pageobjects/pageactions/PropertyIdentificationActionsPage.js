///<reference types ="cypress" />

import PropertyIdentificationElements from '../pageelements/PropertyIdentificationElements'

export default class HomePageActions{

constructor(){

    globalThis.propertyIdentificationElements = new PropertyIdentificationElements()
   
   
   }


 enterPersonalDetails(firstName,lastName,respondentType,postalAddress,suburb,state,postcode,email,phone){

   propertyIdentificationElements.enterFirstName().type(firstName)
   propertyIdentificationElements.enterLastName().type(lastName)
   propertyIdentificationElements.selectRespondentType().click()
   propertyIdentificationElements.selectOwner().click()
   propertyIdentificationElements.enterpostalAddress().type(postalAddress)
   propertyIdentificationElements.enterSuburb().type(suburb)
   propertyIdentificationElements.enterState().type(state)
   propertyIdentificationElements.enterPostCode().type(postcode)
   propertyIdentificationElements.enterEmail().type(email)
   propertyIdentificationElements.enterPhone().type(phone)
   propertyIdentificationElements.clickNextbtn().click()
 }


}