///<reference types ="cypress" />

import HomePageElements from '../pageelements/HomePageElements'

export default class HomePageActions{

constructor(){

  globalThis.homePageElements = new HomePageElements();


}

navigateToUrl(){

  cy.visit('/')

}

startProcess(){

  homePageElements.clickonBegin().click()

}


}