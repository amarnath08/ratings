///<reference types="cypress" />

const OR = require('../../locators.json')

export default class PropertyIdentification{


enterFirstName(){
    return cy.get(OR.PersonalDetails.firstName)
}

enterLastName(){
    return cy.get(OR.PersonalDetails.lastname)
}
selectRespondentType(){
    return cy.get(OR.PersonalDetails.respondentType)
}

selectOwner(){

    return cy.get(OR.PersonalDetails.type)
}

enterpostalAddress(){
    return cy.get(OR.PersonalDetails.postalAddress)
}

enterSuburb(){
    return cy.get(OR.PersonalDetails.suburb)
}
enterState(){
    return cy.get(OR.PersonalDetails.state)
}
enterPostCode(){
    return cy.get(OR.PersonalDetails.postcode)
}
enterEmail(){
    return cy.get(OR.PersonalDetails.email)
}
enterPhone(){
    return cy.get(OR.PersonalDetails.phone)
}

clickNextbtn(){

    return cy.get(OR.PersonalDetails.nextBtn)

}

}