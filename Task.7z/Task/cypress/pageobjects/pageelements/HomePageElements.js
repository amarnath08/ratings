///<reference types="cypress" />

const OR = require('../../locators.json')

export default class HomePageElements{

    clickonBegin(){

        return cy.get(OR.Ratings.beginBtn)

    }

}